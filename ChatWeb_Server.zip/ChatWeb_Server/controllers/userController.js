var User = require("../models/userModel")
const path = require('path');
const bcrypt = require("bcrypt");
var jwt = require('jsonwebtoken');
require("dotenv").config({path: path.resolve(__dirname, '../.env')});

function genCookieAndToken(req, res, user) {
    if(bcrypt.compare(req.body.password, user.password)){
      const token = jwt.sign({ 
        user: 
        {
          username: user.username,   
        }
      },
      process.env.SECRET_KEY || "SECRET_KEY",
        {
          expiresIn: "7d",
        }
      );
      User.update({
        loginToken:token},
        {
          where:
          {
            id:user.id
          }
        }
      ).then(result =>
        console.log(result)
      ).catch(err =>
        console.log(err)
      )
      return res.json({ 
        status: true,user: 
        {
          username: user.username,   
        },
        token:token
      });
    }
  return res.json({ msg: "Incorrect Username or Password", status: false });
}

module.exports.Login = async (req, res, next)=>{
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ where: { username: username } });
    if (!user)
      return res.json({ msg: "Incorrect Username or Password", status: false });
    return genCookieAndToken(req, res, user)
  } catch (ex) {
    next(ex);
    console.log(ex);
  }
  return res.json({ msg: "error", status: false });
}

module.exports.Signin = async (req, res, next)=>{
  try {
    const { username, password, repassword} = req.body;
    if (password!==repassword) return res.json({ msg: "The password and it's confirmation don't match.", status: false });
    await User.findAndCountAll({ where: { username: username} }).then(_=>{
      if (_.count>0)
        return res.json({ msg: "User already exist", status: false });
      bcrypt.hash(password, 10).then(hash=>{
        User.create({
          username: username,
          password: hash,
          }).then(_=>{
              res.json({ msg: "User "+username+" created", status: true })
          }).catch(err=>{
              console.log(err);
              res.json({ msg: "Can't create User", status: false })
          });
      })
    }).catch(err=>{
      next(err);
      console.log(err);
    })
  } catch (ex) {
    next(ex);
    console.log(ex);
  }
  return res;
}