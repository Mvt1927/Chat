const express = require('express');
const cors = require("cors");
// var cookieParser = require('cookie-parser');
// var logger = require('morgan');
const testRoutes = require("./routes/test");
const authRoutes = require("./routes/auth");
var app = express();

app.use(cors());
app.use(express.json());
app.use('/api/test', testRoutes);
app.use('/api/auth', authRoutes);


module.exports = app;
