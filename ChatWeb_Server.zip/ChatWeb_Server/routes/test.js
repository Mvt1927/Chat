var express = require('express');
var router = express.Router();
var passport = require('passport')
const {Login, Signin} = require("../controllers/userController")

/* GET home page. */
router.get('/', function(req, res, next) {
  return res.json({ msg: "Test", status: false });
});
// router.post('/test/:id', function(req, res, next) {
//   return res.json({ msg: req.params.id, status: false });
// });

router.post("/login",Login);
router.post("/signin",Signin);
module.exports = router;
