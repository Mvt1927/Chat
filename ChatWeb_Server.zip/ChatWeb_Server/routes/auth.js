var router = require("express").Router();

const {Login, Signin} = require("../controllers/userController")

router.post("/login",Login);
router.post("/signin",Signin);

module.exports = router;
