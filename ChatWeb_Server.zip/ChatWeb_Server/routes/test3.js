const io = require("socket.io");
const socket = io("http://127.0.0.1:3333/", {
    auth: {
      token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsInVzZXJuYW1lIjoidGVzdDEiLCJpYXQiOjE2NjYwMjQ1NjUsImV4cCI6MTY2NjYyOTM2NX0.dWmU9L7Y0MAl0lThw9JDmDSxc0hdRruMZAo7kJIV2A0",
    },
    transports: ['websocket', 'polling'],
});
socket.on('connect', () => {
    console.log(
      `Connected with socket ID: ${socket.id}. UserID: ${state.me?.id} will join room ${state.poll?.id}`
    );

    actions.stopLoading();
});