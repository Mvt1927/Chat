var {DataTypes, Model } = require('sequelize');
var db = require("./db")

var sequelize = db.sequelize;
var User = Model;

User = sequelize.define("User", {
  id: {
    autoIncrement: true,
    primaryKey: true,
    type: DataTypes.INTEGER,
    unique:true
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  isHasAvartar: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
    default:false
  },
  srcAvartar: {
    type: DataTypes.STRING,
    allowNull: true
  },
  loginToken:{
    type: DataTypes.STRING,
    allowNull: true
  }
})

sequelize.sync().then(() => {
   console.log('Users table created successfully!');
}).catch((error) => {
   console.error('Unable to create table : ', error);
});

module.exports = User


