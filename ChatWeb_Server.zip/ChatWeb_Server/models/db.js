'use strict'
var db = {};
var Sequelize = require('sequelize');
const path = require('path');
require("dotenv").config({path: path.resolve(__dirname, '../.env')});

var sequelize = new Sequelize(
  process.env.DB_DATABASE ||  'test',
  process.env.DB_USERNAME ||  'root',
  process.env.DB_PASSWORD ||  '', 
  {
    host: process.env.DB_HOST ||  'localhost',
    dialect: process.env.DB_CONNECTION ||  'mysql'
});

sequelize.authenticate().then(()=>{
  console.log('Connection has been established successfully.');
})
.catch(()=>{
  console.error('Unable to connect to the database:', error);
})

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;