var User = require('./userModel');
var db = require("./db")
const bcrypt = require("bcrypt");
const { statSync } = require('fs');


// var {QueryTypes} = require('sequelize');
// const { sequelize } = require('./db');
const d = new Date().getTime();

// var password = "admin $2b$10$RQ0VJ.9SuPmIOltXscd06uB7u3JpVk6fkDB.lX4oLqKFYz5ngNUsy"
// var hashedPassword = bcrypt.hashSync(password, 1);
// // var hashedPassword = bcrypt.compareSync(password, "$2b$10$RQ0VJ.9SuPmIOltXscd06uB7u3JpVk6fkDB.lX4oLqKFYz5ngNUsy");
// console.log(hashedPassword);
// User.create({
//     username: "test_"+d,
//     password: hashedPassword,
// }).then(res=>{
//     console.log("ok");
// }).catch(err=>{
//     console.log("no");
//     console.log(err);
//     console.log()
// });
// db,sequelize.query("SELECT `id` FROM `users` WHERE `username`='test_'", { type: QueryTypes.SELECT }).then(user=>{
//     console.log(user?user:"Khong dung");
//     console.log(user.length===0);
// }).catch(err=>{
//     console.log(err);
// })
// User.findByPk(1).then(data => {
//     console.log(data.toJSON());
// });
// User.findOneGet()
User.findAndCountAll({where: { username: 'test_1664444327780'}}).then(user=>{
    console.log(JSON.stringify(user.count));
})
